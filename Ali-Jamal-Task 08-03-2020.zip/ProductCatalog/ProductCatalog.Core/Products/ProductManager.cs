﻿using ProductCatalog.Data.Access.Interfaces;
using ProductCatalog.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductCatalog.Core.Products
{
    public class ProductManager : IProductManager
    {
        private IRepository<Product> repository;
        private IUnitOfWork unitOfWork;
        public ProductManager(IRepository<Product> reposatory, IUnitOfWork unitOfWork)
        {
            this.repository = reposatory;
            this.unitOfWork = unitOfWork;
        }

        public List<Product> Get(string name)
        {
            return repository.Get().Where(x => string.IsNullOrEmpty(name) || x.Name.Contains(name)).ToList();
        }

        public void Create(Product entity)
        {
            repository.Add(entity);
            unitOfWork.Commit();
        }

        public void Update(Product entity)
        {
            entity.LastUpdated=DateTime.Now;
            repository.Update(entity);
            unitOfWork.Commit();
        }
        public void Delete(int id)
        {
            repository.Delete(id);
            unitOfWork.Commit();
        }
    }
}
