﻿using ProductCatalog.Data.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCatalog.Core.Products
{
    public interface IProductManager
    {
        List<Product> Get(string name);
        void Create(Product entity);
        void Update(Product entity);
        void Delete(int id);
    }
}
