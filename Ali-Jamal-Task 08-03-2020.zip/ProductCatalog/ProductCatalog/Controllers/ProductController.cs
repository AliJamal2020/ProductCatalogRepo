﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ProductCatalog.Core.Products;
using ProductCatalog.Data.Model;
using ProductCatalog.Dtos.Products;

namespace ProductCatalog.Controllers
{
    public class ProductController : BaseController
    {
        private IProductManager _Manager;
        IMapper _mapper;
        public ProductController(IProductManager manager, IMapper mapper)
        {
            _Manager = manager;
            _mapper = mapper;
        }


        [HttpGet]
        public List<ProductDto> GetAll(string name)
        {
            var list= _Manager.Get(name);
            return _mapper.Map <List<ProductDto>> (list);
        }

        [HttpPost]
        public void Create(CreateProductDto input)
        {
            var entity = _mapper.Map<Product>(input);
            _Manager.Create(entity);
        }
        [HttpPut]
        public void Update(UpdateProductDto input)
        {
            var entity = _mapper.Map<Product>(input);
            _Manager.Update(entity);
        }
        [HttpDelete]
        public void Delete(int id)
        {
            _Manager.Delete(id);
        }
      
    }
}