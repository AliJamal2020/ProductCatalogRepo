﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using ProductCatalog.Core.Products;
using ProductCatalog.Dtos.Products;

namespace ProductCatalog.Controllers
{
    [Route("[controller]")]
    public class ExportController : Controller
    {
        private IProductManager _Manager;
        IMapper _mapper;
        public ExportController(IProductManager manager, IMapper mapper)
        {
            _Manager = manager;
            _mapper = mapper;
        }


        [HttpGet]
        public IActionResult Export(string name)
        {
            var entities = _Manager.Get(name);
            var list = _mapper.Map<List<ExportProductDto>>(entities);
            string excelName = $"ProductItems-{DateTime.Now.ToString("yyyyMMddHHmmssfff")}.xlsx";

            var stream = new MemoryStream();
            
            using (var package = new ExcelPackage(stream))
            {
                var workSheet = package.Workbook.Worksheets.Add("Sheet1");
                workSheet.Cells.LoadFromCollection(list, true);
               
                for (int i = 0; i < list.Count; i++)
                {
                    var cell = workSheet.Cells[i+2, 4];
                    cell.AutoFitColumns();
                    workSheet.Row(i+2).Height = 100;
                    SetImage(workSheet, cell, entities[i].imgPath);
                }

                workSheet.Column(4).Width = 50;
                
                package.Save();
            }
            stream.Position = 0;
            return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName);
        }

        private static void SetImage(ExcelWorksheet sheet, ExcelRange cell,string path)
        {
            var imgePath = Path.Combine(Directory.GetCurrentDirectory(),path);
            Image image = Image.FromFile(imgePath);
            var picture = sheet.Drawings.AddPicture(Guid.NewGuid().ToString(), image);
            picture.From.Column = cell.Start.Column - 1;
            picture.From.Row = cell.Start.Row - 1;

            picture.To.Column = cell.Start.Column;
            picture.To.Row = cell.Start.Row;
            picture.SetSize(100, 100);
         
        }
    }
}
