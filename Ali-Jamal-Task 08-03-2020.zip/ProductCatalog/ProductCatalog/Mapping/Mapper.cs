﻿using AutoMapper;
using ProductCatalog.Data.Model;
using ProductCatalog.Dtos.Products;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductCatalog.Mapping
{
    public class Mapper : Profile
    {
        public Mapper()
        {
            CreateMap<Product, ProductDto>()
                .ForMember(x => x.LastUpdated, opt => opt.MapFrom(x =>x.LastUpdated.HasValue? x.LastUpdated.Value.ToLongDateString() + " "+ x.LastUpdated.Value.ToLongTimeString() : string.Empty));

            CreateMap<ProductDto, Product>();
            CreateMap<CreateProductDto, Product>();
            CreateMap<UpdateProductDto, Product>();

            CreateMap<Product, ExportProductDto>()
                .ForMember(x => x.LastUpdated, opt => opt.MapFrom(x => x.LastUpdated.HasValue ? x.LastUpdated.Value.ToLongDateString() + " " + x.LastUpdated.Value.ToLongTimeString() : string.Empty));

        }

    }
}
