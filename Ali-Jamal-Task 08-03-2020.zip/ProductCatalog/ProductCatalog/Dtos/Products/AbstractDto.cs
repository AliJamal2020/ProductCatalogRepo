﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductCatalog.Dtos.Products
{
    public class AbstractDto
    {
        public string Name { get; set; }
        public string ImgPath { get; set; }
        public decimal Price { get; set; }
      
    }
}
