﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductCatalog.Dtos.Products
{
    public class ProductDto : AbstractDto
    {
        public int Id { get; set; }
        public string LastUpdated { get; set; }

    }
}
