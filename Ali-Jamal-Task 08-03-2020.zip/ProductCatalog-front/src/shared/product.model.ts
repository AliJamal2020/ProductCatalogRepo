import { Binary } from '@angular/compiler'

export class Product {
    id :number
    name :string
    imgPath : string
    price :string
    lastUpdated :string

 }
 
 export class ProductSearch {
    name :string
    priceFrom : number
    priceTo :number
    lastUpdatedFrom :Date
    lastUpdatedTo:Date

 }
