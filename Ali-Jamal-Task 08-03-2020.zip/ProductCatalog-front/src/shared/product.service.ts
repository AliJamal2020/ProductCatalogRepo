import { Injectable } from '@angular/core';
import { Product } from './Product.model';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { DatePipe } from '@angular/common';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class productService {

  formData:Product;
  list : Product[];
  file=null;
  readonly rootURL ="https://localhost:44362"
  public response: {dbPath: ''};
  searchName:string=""
  
  constructor(private http : HttpClient, private datePipe: DatePipe) { }

  form: FormGroup = new FormGroup({
    id: new FormControl(null),
    name: new FormControl('', Validators.required),
    imgPath: new FormControl(null),
    price: new FormControl('', Validators.required),
    
  });

  initializeFormGroup() {
    this.form.setValue({
      id: null,
      name: '',
      imgPath:null,
      price: null
    });
    this.response= {dbPath: ''};
  }

  postProduct(formData : Product){
    formData.imgPath=this.response.dbPath
    return this.http.post(this.rootURL+'/product/Create',formData);
    
  }

  refreshList(){
    this.http.get(this.rootURL+'/Product/GetAll?name='+this.searchName)
    .subscribe(res => this.list = res as Product[]);
 }


  putProduct(formData : Product){
    if(this.response!=undefined && this.response.dbPath!=''){
      formData.imgPath=this.response.dbPath
    }
    return this.http.put(this.rootURL+'/Product/Update',formData);
   }

   deleteProduct(id : number){
    return this.http.delete(this.rootURL+'/Product/Delete?id='+id);
   }
   
   exportItems(){
  
     this.http.get(this.rootURL+'/Export?name='+this.searchName,  { headers: new HttpHeaders({
      'Content-Type': 'application/octet-stream',
      }), responseType: 'blob'}).subscribe(res=>this.download(res as File));
      
    
   }

   download(exportedFile:File){
    var objectUrl = URL.createObjectURL(exportedFile);
    window.open(objectUrl);
  }

   populateForm(product) {
    this.form.setValue({
      id: product.id,
      name: product.name,
      imgPath:product.imgPath,
      price: product.price
     
    });
  }
}

