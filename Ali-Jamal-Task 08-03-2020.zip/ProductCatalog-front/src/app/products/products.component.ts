import { Component, OnInit } from '@angular/core';
import { productService } from 'src/shared/product.service';
import { Product, ProductSearch } from 'src/shared/Product.model';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { ProdComponent } from './prod/prod.component';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';



@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private service: productService,
    private dialog: MatDialog) { }
  searchModel:ProductSearch=new ProductSearch()
  

  ngOnInit() {
    this.service.refreshList();
  }

  EditForm(ProductDto: Product) {
    this.service.formData = Object.assign({}, ProductDto);
  }

  displayedColumns: string[] = ['name', 'imgPath', 'price', 'lastUpdated','actions'];

  onSearchClear() {
    this.service.searchName = "";
    this.applyFilter();
  }

  applyFilter() {
    this.service.refreshList();
  }

  onCreate() {
    this.service.initializeFormGroup();
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
     this.dialog.open(ProdComponent);
  }

  onEdit(row){
    this.service.populateForm(row);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    this.dialog.open(ProdComponent,dialogConfig);
  }

  public createImgPath = (serverPath: string) => {
    return `https://localhost:44362/${serverPath}`;
  }

  openDialog(id:number): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '350px',
      data: "Do you confirm the deletion of this data?"
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result) {
        this.service.deleteProduct(id).subscribe(x=>this.service.refreshList());
      }
    });
  }

  exportItems(){
    this.service.exportItems();
  }


}
