import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { productService } from 'src/shared/product.service';

@Component({
  selector: 'app-prod',
  templateUrl: './prod.component.html',
  styleUrls: ['./prod.component.css']
})
export class ProdComponent implements OnInit {

  	

   constructor(private service: productService,
    public dialogRef: MatDialogRef<ProdComponent>) { }
  ngOnInit() {
  }

  onClear() {
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  onSubmit() {
    if (this.service.form.valid) {

      if (!this.service.form.get('id').value){
        this.service.postProduct(this.service.form.value).subscribe(x=> this.service.refreshList());
      }
     
      else{
        this.service.putProduct(this.service.form.value).subscribe(x=> this.service.refreshList());;
      }
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.onClose();
     
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();
  }


  public uploadFinished = (event) => {
      this.service.response = event;
    }

}
