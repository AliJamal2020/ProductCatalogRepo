import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProductsComponent } from './products/products.component';
import { MaterialModule } from 'src/material/material.module';
import { productService } from 'src/shared/product.service';
import { HttpClientModule } from '@angular/common/http'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ProdComponent } from './products/prod/prod.component';
import { UploadComponent } from './upload/upload.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';



@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    ProdComponent,
    UploadComponent,
    ConfirmationDialogComponent
    ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [productService,DatePipe],
  bootstrap: [AppComponent],
  entryComponents:[
    ProdComponent,
    ConfirmationDialogComponent
  ]
})
export class AppModule { }
